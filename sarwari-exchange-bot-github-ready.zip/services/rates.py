import asyncio
import logging
from typing import Any

import requests

from models import ProviderResult

logger = logging.getLogger(__name__)


class RatesService:
    """
    Rate provider layer used by bot.py.

    The reference provider works out of the box with the public
    open.er-api.com endpoint. Optional XE/DAB/Gold endpoints can be
    supplied through environment variables.

    This keeps the bot deployable even when optional providers are not
    configured yet.
    """

    def __init__(self, settings):
        self.settings = settings

    async def _get_json(self, url: str, headers: dict[str, str] | None = None) -> dict[str, Any]:
        if not url:
            return {}
        def request():
            response = requests.get(url, headers=headers or {}, timeout=15)
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict):
                raise ValueError("Provider returned a non-object JSON response")
            return data
        return await asyncio.to_thread(request)

    @staticmethod
    def _number(value: Any) -> float | None:
        try:
            if value is None or value == "":
                return None
            return float(value)
        except (TypeError, ValueError):
            return None

    async def get_reference_rates(self) -> ProviderResult:
        try:
            data = await self._get_json(self.settings.reference_rates_url)
            rates = data.get("rates", {})
            if not isinstance(rates, dict):
                raise ValueError("Reference provider has no rates object")

            normalized = {}
            for code in ("AFN", "EUR", "GBP", "USD", "AED", "TRY", "CAD", "AUD"):
                value = self._number(rates.get(code))
                if value is not None:
                    normalized[code] = value

            # The provider is USD based by default. If USD itself is not
            # returned, keep an empty result rather than inventing a rate.
            if not normalized:
                return ProviderResult(message="No usable reference rates returned.")
            return ProviderResult(rates=normalized, available=True)
        except (requests.RequestException, ValueError, TypeError, KeyError) as exc:
            logger.warning("Reference rates failed: %s", exc)
            return ProviderResult(message=str(exc))

    async def get_xe(self) -> ProviderResult:
        if not self.settings.xe_url:
            return ProviderResult(
                rates={},
                available=False,
                message="XE provider is not configured.",
            )
        try:
            data = await self._get_json(self.settings.xe_url)
            rates = data.get("rates", {})
            if not isinstance(rates, dict):
                rates = {}
            normalized = {
                code: value
                for code in ("AFN", "EUR", "GBP", "USD", "AED", "TRY")
                if (value := self._number(rates.get(code))) is not None
            }
            return ProviderResult(rates=normalized, available=bool(normalized))
        except (requests.RequestException, ValueError, TypeError, KeyError) as exc:
            logger.warning("XE provider failed: %s", exc)
            return ProviderResult(message=str(exc))

    async def get_dab(self) -> ProviderResult:
        if not self.settings.dab_url:
            return ProviderResult(
                rates={},
                available=False,
                message="DAB provider is not configured.",
            )
        try:
            data = await self._get_json(self.settings.dab_url)
            rates = data.get("rates", data)
            if not isinstance(rates, dict):
                rates = {}
            normalized = {
                str(code).upper(): value
                for code, raw in rates.items()
                if (value := self._number(raw)) is not None
            }
            return ProviderResult(rates=normalized, available=bool(normalized))
        except (requests.RequestException, ValueError, TypeError, KeyError) as exc:
            logger.warning("DAB provider failed: %s", exc)
            return ProviderResult(message=str(exc))

    async def get_gold(self) -> ProviderResult:
        if not self.settings.gold_url:
            return ProviderResult(
                gold={},
                available=False,
                message="Gold provider is not configured.",
            )

        headers = {}
        if self.settings.gold_api_key:
            headers["X-API-Key"] = self.settings.gold_api_key
            headers["Authorization"] = f"Bearer {self.settings.gold_api_key}"

        try:
            data = await self._get_json(self.settings.gold_url, headers=headers)

            # Accept a few common JSON shapes without fabricating values.
            gold = data.get("gold") if isinstance(data.get("gold"), dict) else data
            if not isinstance(gold, dict):
                gold = {}

            normalized = {}
            for key, value in gold.items():
                number = self._number(value)
                if number is not None:
                    normalized[str(key)] = number

            if not normalized:
                return ProviderResult(message="Gold provider returned no numeric values.")
            return ProviderResult(gold=normalized, available=True)
        except (requests.RequestException, ValueError, TypeError, KeyError) as exc:
            logger.warning("Gold provider failed: %s", exc)
            return ProviderResult(message=str(exc))

    async def refresh_reference_rates(self) -> ProviderResult:
        return await self.get_reference_rates()

    async def refresh_gold(self) -> ProviderResult:
        return await self.get_gold()
