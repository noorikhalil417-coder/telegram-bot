from typing import Any


def _fmt(value: Any) -> str:
    try:
        number = float(value)
        if number.is_integer():
            return f"{int(number):,}"
        return f"{number:,.4f}".rstrip("0").rstrip(".")
    except (TypeError, ValueError):
        return str(value)


def format_reference_rates(rates: dict[str, float]) -> str:
    labels = {
        "AFN": "افغانی",
        "EUR": "یورو",
        "GBP": "پوند",
        "USD": "دالر",
        "AED": "درهم",
        "TRY": "لیر",
        "CAD": "دالر کانادا",
        "AUD": "دالر استرالیا",
    }
    lines = ["📊 نرخ اسعار", "━━━━━━━━━━━━━━━", ""]
    for code, label in labels.items():
        if code in rates:
            lines.append(f"💱 {label} ({code}): {_fmt(rates[code])}")
    if len(lines) == 3:
        return "⚠️ نرخ قابل نمایش دریافت نشد."
    lines.extend(["", "ℹ️ منبع نرخ: سرویس مرجع آنلاین"])
    return "\n".join(lines)


def format_xe_rates(rates: dict[str, float]) -> str:
    if not rates:
        return "⚠️ نرخ XE در دسترس نیست."
    lines = ["🌍 نرخ XE", "━━━━━━━━━━━━━━━", ""]
    for code, value in rates.items():
        lines.append(f"💱 {code}: {_fmt(value)}")
    return "\n".join(lines)


def format_dab_rates(rates: dict[str, float]) -> str:
    if not rates:
        return "⚠️ نرخ DAB در دسترس نیست."
    lines = ["🏦 نرخ د افغانستان بانک", "━━━━━━━━━━━━━━━", ""]
    for code, value in rates.items():
        lines.append(f"💱 {code}: {_fmt(value)}")
    return "\n".join(lines)


def format_comparison(
    reference_rates: dict[str, float],
    xe_rates: dict[str, float],
    dab_available: bool,
) -> str:
    lines = ["📊 مقایسه نرخ‌ها", "━━━━━━━━━━━━━━━", ""]
    for code in ("AFN", "EUR", "GBP", "AED", "TRY"):
        parts = []
        if code in reference_rates:
            parts.append(f"مرجع: {_fmt(reference_rates[code])}")
        if code in xe_rates:
            parts.append(f"XE: {_fmt(xe_rates[code])}")
        if parts:
            lines.append(f"💱 {code} | " + " | ".join(parts))
    lines.append("")
    lines.append(f"🏦 د افغانستان بانک: {'در دسترس' if dab_available else 'تنظیم نشده'}")
    return "\n".join(lines)


def format_gold(gold: dict[str, Any]) -> str:
    if not gold:
        return "⚠️ اطلاعات نرخ طلا در دسترس نیست."
    lines = ["🥇 نرخ طلا", "━━━━━━━━━━━━━━━", ""]
    preferred = [
        ("price", "قیمت"),
        ("price_gram_24k", "هر گرم ۲۴ عیار"),
        ("price_gram_22k", "هر گرم ۲۲ عیار"),
        ("ounce", "اونس"),
        ("xau_usd", "XAU/USD"),
    ]
    used = set()
    for key, label in preferred:
        if key in gold:
            lines.append(f"🪙 {label}: {_fmt(gold[key])}")
            used.add(key)
    for key, value in gold.items():
        if key not in used:
            lines.append(f"🪙 {key}: {_fmt(value)}")
    return "\n".join(lines)
